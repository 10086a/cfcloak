## This is the transform tool for both the hadoop tests and java tests.  
* MyMain is the main program.

 **NOTICE: THE PATH TO THE JAR IN TRANSFORME SCRIPT AND THE MAIN CLASS CLALLING TO**   
