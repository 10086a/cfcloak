## javaJNI is the interface for java tests to call the c++ shared object  
### you can modify the interface, then  
    $ javac your-java-invoker.java
    $ javah -jni your-java-invoker    
### The compiled \*.h file should be put into *SGXNew/App* 
