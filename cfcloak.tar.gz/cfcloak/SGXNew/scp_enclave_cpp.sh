scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.cpp  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.cpp  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.cpp  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/

scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.config.xml  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.config.xml  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.config.xml  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/

scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.edl  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.edl  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.edl  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/

scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.h  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.h  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/Enclave.h  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Enclave/

scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/App.cpp  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/App.cpp  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/App.cpp  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/

scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Include/hot_calls.h  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Include/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Include/hot_calls.h  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Include/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Include/hot_calls.h  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/Include/

scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/invoker_sgx_invoker.h  xidian@192.168.1.152:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/invoker_sgx_invoker.h  xidian@192.168.1.153:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/
scp /home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/invoker_sgx_invoker.h  xidian@192.168.1.154:/home/xidian/ZyStBleforSGX/cfhider/SGX/SGXNew/App/
