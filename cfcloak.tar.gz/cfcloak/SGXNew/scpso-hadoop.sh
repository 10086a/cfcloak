cp *.so ~/hadoop/lib/native/Linux-amd64-64/
scp *.so xidian@192.168.1.152:/home/xidian/hadoop/lib/native/Linux-amd64-64/
scp *.so xidian@192.168.1.153:/home/xidian/hadoop/lib/native/Linux-amd64-64/
scp *.so xidian@192.168.1.154:/home/xidian/hadoop/lib/native/Linux-amd64-64/

