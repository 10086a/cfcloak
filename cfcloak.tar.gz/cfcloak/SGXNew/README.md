### How do I get set up?  
make clean
make

# script for hadoop case
scp_enclave_cpp.sh
scpso-hadoop.sh

# FOLDERS  
### Include
hotcall

### App
the interface function
### Enclave  
the impl
