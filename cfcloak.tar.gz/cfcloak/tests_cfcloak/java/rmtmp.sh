# ./1runorigin.sh
# ./2runorigin.sh
# ./3runorigin.sh
# ./4runorigin.sh
# ./5runorigin.sh
# ./6runorigin.sh

#cd index-bak
#./scpreplaceindex.sh
#cd ..
#./1runreplace.sh
# ./2runreplace.sh
# ./3runreplace.sh
# ./4runreplace.sh
# ./5runreplace.sh
# ./6runreplace.sh


#cd index-bak
#./scp30index.sh
#cd ..
#./1run30.sh
# ./2run30.sh
# ./3run30.sh
# ./4run30.sh
# ./5run30.sh
# ./6run30.sh



#cd index-bak
#./scp50index.sh
#cd ..
#./1run50.sh
# ./2run50.sh
# ./3run50.sh
# ./4run50.sh
# ./5run50.sh
# ./6run50.sh

rm -f /tmp/SGXindex
#rm -f /tmp/SGXinvoke
