## There are Bubble Sort, Quick Sort and BinarySearch tests in this folder.
    $ ./tmtmp.sh
    $ ./SGX-transformer.sh  
    $ ./encrypt_SGXindex.sh

## add the SGX path to LD_LIBRARY_PATH  
    $ export LD_LIBRARY_PATH=/home/xidian/cfcloak/SGXNew/  or  
    $ export LD_LIBRARY_PATH=/YOUR/PATH/TO/cfcloak/SGXNew/  

## Then run the transformed class  
    $ cd replaceOutput  
    $ java test.Sort_*  or  
    $ java test.BinarySearch

