scp /tmp/SGXindex xidian@192.168.1.152:/tmp/
scp /tmp/SGXindex xidian@192.168.1.153:/tmp/
scp /tmp/SGXindex xidian@192.168.1.154:/tmp/

