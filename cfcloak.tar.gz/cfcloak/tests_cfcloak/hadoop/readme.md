# Preparation for Hadoop testcases  
# FOLDERS  
### hadoopPI

### hadoopWordCount

### hadoopSort

### Hibench/pagerank
