# 0. prepare data
    $ cd /bin
    $ ./prepare(0-5).sh
    $ cd ..
# 1. Buid and run original java files
    $ ./build_pegasus.sh  
    $ cd /bin
    $ ./run(0-5).sh  
# 2. transform origin class files to new ones with SGX (only replace the conditions)
    $ ./Hadoop-SGX-transformer.sh
## encrypt SGXindex  
    $ ./encrypt_SXGindex.sh  
##the encrypted SGXindex file should be */tmp/* on every nodes in the cluster.(scp)  
    $ ./scpreplaceindex.sh
## runing this new files
    $ cd /bin
    $ ./run-SGX(0-5).sh  
## NOTICE: BEFORE TRANSFORM THE CLASS FILES, TO CLEAN THE *SGXindex* IN THE */tmp*.
