find TransFakeSegmentForJni/ -name "*.class" -type f -print -exec rm -rf {} \;
find TransFakeSegmentForJni/ -name "*.jar" -type f -print -exec rm -rf {} \;

#cp -f sgx_invoker.class ./pbin/pegasus/sgx_invoker.class

java -Xms512M -Xmx1024M -cp /home/xidian/Development/soot-lib/symja-2015-09-26.jar:/home/xidian/Development/soot-lib/jasminclasses-custom.jar:/home/xidian/Development/soot-lib/polyglotclasses-1.3.5.jar:/home/xidian/Development/soot-lib/soot-trunk.jar:/home/xidian/Development/soot-lib/commons-io-2.4.jar:/home/xidian/Development/soot-lib/log4j-1.2.11.jar:/home/xidian/ZyStBleforSGX/cfhider/soot-code/CFHiderNew/testcase.jar  MyMain -allow-phantom-refs -cp .:/usr/lib/jvm/jdk1.7.0_79/jre/lib/rt.jar:/usr/lib/jvm/jdk1.7.0_79/jre/lib/jce.jar:/home/xidian/hadoop-1.0.4/hadoop-core-1.0.4.jar:/home/xidian/hadoop-1.0.4/hadoop-tools-1.0.4.jar:/home/xidian/Development/soot-lib/commons-logging-1.1.3.jar:/home/xidian/Development/soot-lib/commons-cli-1.2.jar:/usr/local/hadoop-1.0.4/hadoop-core-1.0.4.jar:/home/xidian/hadoop-1.0.4/lib/commons-cli-1.2.jar -src-prec c -f c -include-all -process-dir ./pbin -output-dir ./TransFakeSegmentForJni

cp -f PegasusUtils.class ./TransFakeSegmentForJni/pegasus/PegasusUtils.class

cd TransFakeSegmentForJni/

jar -cfm pegasus-2.0-SGX.jar a.txt pegasus/ invoker/
