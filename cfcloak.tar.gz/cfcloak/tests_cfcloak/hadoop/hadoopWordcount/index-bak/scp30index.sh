cp ./30/SGXindex ./30/counter /tmp/
scp ./30/SGXindex ./30/counter xidian@192.168.1.152:/tmp/
scp ./30/SGXindex ./30/counter xidian@192.168.1.153:/tmp/
scp ./30/SGXindex ./30/counter xidian@192.168.1.153:/tmp/
