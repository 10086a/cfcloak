scp ./replace/SGXindex ./replace/counter xidian@192.168.1.152:/tmp/
scp ./replace/SGXindex ./replace/counter xidian@192.168.1.153:/tmp/
scp ./replace/SGXindex ./replace/counter xidian@192.168.1.154:/tmp/
cp ./replace/SGXindex ./replace/counter /tmp/
