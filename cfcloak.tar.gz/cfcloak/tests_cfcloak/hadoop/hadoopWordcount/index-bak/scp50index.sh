scp ./50/SGXindex ./50/counter xidian@192.168.1.152:/tmp/
scp ./50/SGXindex ./50/counter xidian@192.168.1.153:/tmp/
scp ./50/SGXindex ./50/counter xidian@192.168.1.154:/tmp/
cp ./50/SGXindex ./50/counter /tmp/
