jar -cfm ReplaceTestforHadoopWordCount.jar ../META-INF/MANIFEST.MF cfhider/ invoker/
