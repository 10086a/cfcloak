# 0. prepare data
    $ ./prepare(1-6).sh
# 1. Buid and run original java files
    $ ./build-origin.sh  
    $ ./run-origin.sh  
# 2. transform origin class files to new ones with SGX (only replace the conditions)
    $ ./replace-transformer.sh  
## encrypt SGXindex  
    $ ./encrypt_SXGindex.sh  
##the encrypted SGXindex file should be */tmp/* on every nodes in the cluster.(scp)  
    $ ./scpreplaceindex.sh
## runing this new files
    $ ./(1-6)runreplace.sh  
## NOTICE: BEFORE TRANSFORM THE CLASS FILES, TO CLEAN THE *SGXindex* IN THE */tmp*.
