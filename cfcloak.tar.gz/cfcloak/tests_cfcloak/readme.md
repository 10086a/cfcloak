# There are 3 Hadoop applications that selected from the hadoop 1.0.4 release package and Hibench and 3 simple java application to test the applicability and the performance of CFHider. 

 **NOTICE: THE PATH TO THE JAR IN TRANSFORME SCRIPT AND THE MAIN CLASS CLALLING TO**   
